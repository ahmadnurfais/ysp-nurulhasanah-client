<?php
 // update
if(!defined('ABSPATH')){
	die('-1');
} 

 
Class Risehand_update{
// check updates
}
 
new Risehand_update(); 