<?php
/*
**=============================================   
** Get Extender Files
**=============================================
*/ 
// Cookies
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/cookies/cookies.php'; 
// deals
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/deals/deal.php'; 
// Quick view
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/quick-view/quick-view.php'; 
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/quick-view/quick-view-template.php';
// Infinite and load more 
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/load-infinite/load-infinite.php';  
// share 
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/share/share.php';   
// Welcome file
require_once RISEHAND_ADDONS_DIR . 'includes/Extended/welcome/welcome.php';    