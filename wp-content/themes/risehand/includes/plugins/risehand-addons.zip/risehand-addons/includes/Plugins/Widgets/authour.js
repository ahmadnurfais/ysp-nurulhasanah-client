jQuery(document).ready(function ($) {
    // Media uploader
    $('.color-picker').wpColorPicker();
 
});

 
